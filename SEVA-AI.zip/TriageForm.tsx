import { useState } from "react";
import { motion } from "framer-motion";
import { UserPlus, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { PatientData } from "@/lib/allocation";

interface TriageFormProps {
  onAllocate: (data: PatientData) => void;
  onReset: () => void;
}

const initialState: PatientData = {
  name: "",
  age: 0,
  bp: 0,
  spo2: 0,
  hr: 0,
  symptoms: "",
};

const TriageForm = ({ onAllocate, onReset }: TriageFormProps) => {
  const [form, setForm] = useState<PatientData>(initialState);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    onAllocate(form);
  };

  const handleReset = () => {
    setForm(initialState);
    onReset();
  };

  const update = (field: keyof PatientData, value: string | number) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="rounded-2xl border border-border bg-card p-6 shadow-card"
    >
      <div className="mb-5 flex items-center gap-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-subtle">
          <UserPlus className="h-4 w-4 text-primary" />
        </div>
        <h2 className="text-base font-semibold text-foreground">Triage Console</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label htmlFor="name" className="text-xs font-medium text-muted-foreground">Patient Name</Label>
          <Input id="name" placeholder="Full name" value={form.name} onChange={(e) => update("name", e.target.value)} className="mt-1" />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="age" className="text-xs font-medium text-muted-foreground">Age</Label>
            <Input id="age" type="number" placeholder="0" value={form.age || ""} onChange={(e) => update("age", +e.target.value)} className="mt-1" />
          </div>
          <div>
            <Label htmlFor="bp" className="text-xs font-medium text-muted-foreground">BP (mmHg)</Label>
            <Input id="bp" type="number" placeholder="120" value={form.bp || ""} onChange={(e) => update("bp", +e.target.value)} className="mt-1" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="spo2" className="text-xs font-medium text-muted-foreground">SpO₂ (%)</Label>
            <Input id="spo2" type="number" placeholder="98" value={form.spo2 || ""} onChange={(e) => update("spo2", +e.target.value)} className="mt-1" />
          </div>
          <div>
            <Label htmlFor="hr" className="text-xs font-medium text-muted-foreground">HR (bpm)</Label>
            <Input id="hr" type="number" placeholder="72" value={form.hr || ""} onChange={(e) => update("hr", +e.target.value)} className="mt-1" />
          </div>
        </div>

        <div>
          <Label htmlFor="symptoms" className="text-xs font-medium text-muted-foreground">Symptoms</Label>
          <Textarea id="symptoms" placeholder="Describe symptoms..." rows={3} value={form.symptoms} onChange={(e) => update("symptoms", e.target.value)} className="mt-1 resize-none" />
        </div>

        <div className="flex gap-3 pt-2">
          <Button type="submit" className="flex-1 gradient-primary text-primary-foreground border-0 hover:opacity-90 transition-opacity">
            <UserPlus className="mr-2 h-4 w-4" />
            Allocate
          </Button>
          <Button type="button" variant="outline" onClick={handleReset} className="transition-colors">
            <RotateCcw className="mr-2 h-4 w-4" />
            Reset
          </Button>
        </div>
      </form>
    </motion.div>
  );
};

export default TriageForm;
