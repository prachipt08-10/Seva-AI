export interface PatientData {
  name: string;
  age: number;
  bp: number;
  spo2: number;
  hr: number;
  symptoms: string;
}

export interface AllocationResult {
  priorityScore: number;
  category: "moderate" | "critical";
  allocatedBed: string;
  decision: string;
  resources: {
    icu: number;
    general: number;
    ventilator: number;
  };
}

const CRITICAL_SYMPTOMS = [
  "chest pain", "breathing difficulty", "unconscious", "seizure",
  "stroke", "cardiac arrest", "severe bleeding", "trauma",
  "respiratory failure", "shock", "cyanosis", "anaphylaxis",
];

let icuBeds = 12;
let generalBeds = 30;
let ventilators = 8;
let icuCounter = 0;
let generalCounter = 0;

export function allocatePatient(data: PatientData): AllocationResult {
  let score = 0;

  // SpO2 scoring (lower = worse)
  if (data.spo2 < 90) score += 40;
  else if (data.spo2 < 94) score += 25;
  else if (data.spo2 < 97) score += 10;

  // Heart rate scoring
  if (data.hr > 120) score += 30;
  else if (data.hr > 100) score += 20;
  else if (data.hr > 90) score += 10;

  // BP scoring
  if (data.bp > 180 || data.bp < 80) score += 25;
  else if (data.bp > 140 || data.bp < 90) score += 15;

  // Age scoring
  if (data.age > 70) score += 15;
  else if (data.age > 55) score += 10;

  // Symptom scoring
  const symptomsLower = data.symptoms.toLowerCase();
  for (const symptom of CRITICAL_SYMPTOMS) {
    if (symptomsLower.includes(symptom)) {
      score += 20;
      break;
    }
  }

  const isCritical = score >= 50;
  const category = isCritical ? "critical" : "moderate";

  let allocatedBed: string;
  let decision: string;

  if (isCritical && icuBeds > 0) {
    icuCounter++;
    icuBeds--;
    allocatedBed = `ICU-${icuCounter}`;
    decision = "ICU Admission";
  } else {
    generalCounter++;
    if (generalBeds > 0) generalBeds--;
    allocatedBed = `G-${generalCounter}`;
    decision = "General Ward";
  }

  return {
    priorityScore: Math.min(score, 100),
    category,
    allocatedBed,
    decision,
    resources: {
      icu: icuBeds,
      general: generalBeds,
      ventilator: ventilators,
    },
  };
}

export function resetResources() {
  icuBeds = 12;
  generalBeds = 30;
  ventilators = 8;
  icuCounter = 0;
  generalCounter = 0;
}
