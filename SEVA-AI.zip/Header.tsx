import { Activity } from "lucide-react";

const Header = () => {
  return (
    <header className="border-b border-border bg-card shadow-card">
      <div className="container mx-auto flex items-center justify-between px-4 py-3 sm:px-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl gradient-primary">
            <Activity className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-lg font-bold leading-tight text-foreground">
              HealSense AI
            </h1>
            <p className="text-xs font-medium text-muted-foreground">
              Resource Allocation Engine
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="hidden items-center gap-1.5 rounded-lg bg-secondary px-3 py-1.5 text-xs font-medium text-secondary-foreground sm:flex">
            <span className="h-2 w-2 rounded-full bg-stable animate-pulse" />
            System Online
          </span>
        </div>
      </div>
    </header>
  );
};

export default Header;
