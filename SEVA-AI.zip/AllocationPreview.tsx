import { motion, AnimatePresence } from "framer-motion";
import { Activity, Bed, Wind, Copy, Download, AlertTriangle, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AllocationResult } from "@/lib/allocation";
import { toast } from "sonner";

interface AllocationPreviewProps {
  result: AllocationResult | null;
}

const AllocationPreview = ({ result }: AllocationPreviewProps) => {
  const copyJSON = () => {
    if (!result) return;
    navigator.clipboard.writeText(JSON.stringify(result, null, 2));
    toast.success("JSON copied to clipboard");
  };

  const downloadJSON = () => {
    if (!result) return;
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "allocation-result.json";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.1 }}
      className="space-y-4"
    >
      {/* Priority Card */}
      <div className="rounded-2xl border border-border bg-card p-6 shadow-card">
        <div className="mb-4 flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-subtle">
            <Activity className="h-4 w-4 text-primary" />
          </div>
          <h2 className="text-base font-semibold text-foreground">Live Allocation Preview</h2>
        </div>

        <AnimatePresence mode="wait">
          {result ? (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-4"
            >
              {/* Category & Score */}
              <div className="flex items-center justify-between">
                <span
                  className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold uppercase ${
                    result.category === "critical"
                      ? "bg-critical/10 text-critical"
                      : "bg-moderate/10 text-moderate"
                  }`}
                >
                  {result.category === "critical" ? (
                    <AlertTriangle className="h-3 w-3" />
                  ) : (
                    <CheckCircle className="h-3 w-3" />
                  )}
                  {result.category}
                </span>
                <span className="text-2xl font-bold text-foreground">
                  {result.priorityScore}
                  <span className="text-sm font-normal text-muted-foreground">/100</span>
                </span>
              </div>

              {/* Progress Bar */}
              <div className="h-2.5 w-full overflow-hidden rounded-full bg-secondary">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${result.priorityScore}%` }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                  className={`h-full rounded-full ${
                    result.category === "critical" ? "bg-critical" : "bg-moderate"
                  }`}
                />
              </div>

              {/* Decision */}
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl bg-secondary/60 p-3">
                  <p className="text-xs text-muted-foreground">Decision</p>
                  <p className="text-sm font-semibold text-foreground">{result.decision}</p>
                </div>
                <div className="rounded-xl bg-secondary/60 p-3">
                  <p className="text-xs text-muted-foreground">Bed Assigned</p>
                  <p className="text-sm font-semibold text-foreground">{result.allocatedBed}</p>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              className="flex flex-col items-center justify-center py-8 text-center"
            >
              <Activity className="mb-3 h-10 w-10 text-muted-foreground/30" />
              <p className="text-sm text-muted-foreground">
                Submit patient data to see allocation results
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Resources Card */}
      <div className="rounded-2xl border border-border bg-card p-6 shadow-card">
        <h3 className="mb-3 text-sm font-semibold text-foreground">Available Resources</h3>
        <div className="grid grid-cols-3 gap-3">
          <ResourceTile icon={<Bed className="h-4 w-4" />} label="ICU Beds" value={result?.resources.icu ?? 12} />
          <ResourceTile icon={<Bed className="h-4 w-4" />} label="General" value={result?.resources.general ?? 30} />
          <ResourceTile icon={<Wind className="h-4 w-4" />} label="Ventilators" value={result?.resources.ventilator ?? 8} />
        </div>
      </div>

      {/* JSON Output */}
      {result && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="rounded-2xl border border-border bg-card p-6 shadow-card"
        >
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-foreground">Raw JSON Output</h3>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={copyJSON} className="h-7 text-xs">
                <Copy className="mr-1 h-3 w-3" /> Copy
              </Button>
              <Button size="sm" variant="outline" onClick={downloadJSON} className="h-7 text-xs">
                <Download className="mr-1 h-3 w-3" /> Download
              </Button>
            </div>
          </div>
          <pre className="max-h-48 overflow-auto rounded-lg bg-secondary/60 p-3 text-xs text-foreground">
            {JSON.stringify(result, null, 2)}
          </pre>
        </motion.div>
      )}
    </motion.div>
  );
};

const ResourceTile = ({ icon, label, value }: { icon: React.ReactNode; label: string; value: number }) => (
  <div className="flex flex-col items-center gap-1 rounded-xl bg-secondary/60 p-3 text-center">
    <span className="text-muted-foreground">{icon}</span>
    <span className="text-lg font-bold text-foreground">{value}</span>
    <span className="text-[10px] font-medium text-muted-foreground">{label}</span>
  </div>
);

export default AllocationPreview;
