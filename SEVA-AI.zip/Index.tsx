import { useState } from "react";
import Header from "@/components/Header";
import TriageForm from "@/components/TriageForm";
import AllocationPreview from "@/components/AllocationPreview";
import { allocatePatient, resetResources, PatientData, AllocationResult } from "@/lib/allocation";

const Index = () => {
  const [result, setResult] = useState<AllocationResult | null>(null);

  const handleAllocate = (data: PatientData) => {
    const allocation = allocatePatient(data);
    setResult(allocation);
  };

  const handleReset = () => {
    resetResources();
    setResult(null);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-6 sm:px-6">
        <div className="grid gap-6 lg:grid-cols-[400px_1fr]">
          <TriageForm onAllocate={handleAllocate} onReset={handleReset} />
          <AllocationPreview result={result} />
        </div>
      </main>
    </div>
  );
};

export default Index;
